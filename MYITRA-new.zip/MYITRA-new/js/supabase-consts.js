// js/supabase-consts.js
export const SUPABASE_URL = "https://szfpwaascymteojkcmeb.supabase.co";
export const SUPABASE_ANON = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InN6ZnB3YWFzY3ltdGVvamtjbWViIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjMxMzYzNDUsImV4cCI6MjA3ODcxMjM0NX0.3t74vMgm19iB4INDNruCfKz8QrHWcOK81Iks-os3t2A";
